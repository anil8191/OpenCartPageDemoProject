
package com.test.ui.helper;

import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import lombok.extern.slf4j.Slf4j;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;

import com.test.browser.setup.GeneralBrowserSetting;

/**
 * @author anil
 *
 * Feb 4, 2023
 */


@Slf4j
@SuppressWarnings("static-access")
public class CommanUtill extends GeneralBrowserSetting {

	static Logger log = Logger.getLogger(CommanUtill.class);


	// Close All the windows function
	public static void closeallwindow() throws IOException, InterruptedException{
		try{
			log.info("End all the execution...");
			driver.quit();
			log.info("Closed the all windows...");
		}
		catch (Exception E){   
			System.out.println("Error while closing all the window... " +E.getMessage());
		}    
	}

	
	public static void click(String xmlPath, String fieldName) throws IOException, InterruptedException{
		customWait(1);
		try{
			log.info("Start Clicking on (" +fieldName+ ")");
			logger.info("Start Clicking on (" +fieldName+ ")");
			passedScreenShotPics();		//Capturing Screenshot
			driver.findElement(By.xpath(xmlPath)).click();
			passedScreenShotPics();		//Capturing Screenshot
			System.out.println("Clicked on (" +fieldName+ ")");
			log.info("Clicked on (" +fieldName+ ")");
			logger.pass("Clicked on (" +fieldName+ ")");
			customWait(2);
		}
		catch (Exception e){ 
			failureScreenShotPics();
			logger.fail(xmlPath +": Not able to locate web element for field (" +fieldName+ ")"+e.getMessage());
			log.info(xmlPath +": Not able to locate web element for field (" +fieldName+ ")"+e.getMessage());
			Assert.fail("Error while Clicking on the web element... "+e.getMessage());
		}  
	}


	public static void enterText(String xmlPath, String inputData, String fieldName) throws IOException, InterruptedException{
		customWait(1);
		try{
			log.info("Start entering the text on (" +fieldName+ ")");
			logger.info("Start entering the text on (" +fieldName+ ")");
			passedScreenShotPics();
			driver.findElement(By.xpath(xmlPath)).clear();
			driver.findElement(By.xpath(xmlPath)).sendKeys(inputData);
			passedScreenShotPics();
			System.out.println("Entered text on (" +fieldName+ ")");
			log.info("Entered text on (" +fieldName+ ")");
			logger.pass("Entered text on (" +fieldName+ ")");
			logger.info("Entered text on (" +fieldName+ ")");
			customWait(1);
		}
		catch (Exception e){
			failureScreenShotPics();
			logger.fail(xmlPath +": Not able to locate web element for field (" +fieldName+ ")");
			log.info(xmlPath +": Not able to locate web element for field (" +fieldName+ ")");
			Assert.fail("Error while entering the text on the web element... "+e.getMessage());
		}  
	}

	public static String validateText(String xmlPath, String fieldName) throws IOException, InterruptedException{
		customWait(1);
		String appText = "";
		try{
			passedScreenShotPics();
			appText = driver.findElement(By.xpath(xmlPath)).getText().trim();
			customWait(2);
			System.out.println("Got the webelement text "+appText+ "(from " +fieldName+ ")");
			log.info("Got the webelement text "+appText+ "(from " +fieldName+ ")");
			logger.info("Got the webelement text "+appText+ "(from " +fieldName+ ")");
			customWait(1);
		}
		catch (Exception e){
			failureScreenShotPics();
			logger.fail(xmlPath +": Not able to get the web element text for field (" +fieldName+ ")");
			log.info(xmlPath +": Not able to get the web element text for field (" +fieldName+ ")");
			Assert.fail("Error while fetching the text on the web element... "+e.getMessage());
		}
		return appText;
	}

	public static void validateSubCategory(String xmlPath, String fieldName) throws InterruptedException, IOException{
		String newXPath = null;
		String index;
		List<WebElement> webList = driver.findElements(By.xpath(xmlPath));
		passedScreenShotPics();
		int size = webList.size();
		for(int i = 0; i < size; i++){
			index = webList.get(i).getText().trim();
			newXPath = xmlPath+"[.='"+index+"']";
			mouseHover(newXPath);
			log.info("Validated the category !!!");
			logger.pass("Validated the category !!!");
			customWait(1);
		}
	}


	// All text validation, common function
	public void alltextValidation(String xmlPath, String inputdata) throws IOException, InterruptedException{
		if (inputdata.toString().equals("")){
			System.out.println(xmlPath+": No input data");
			logger.info(xmlPath+": No input data");
		}
		else{
			try{
				Thread.sleep(500);
				log.info("Validation Start...");
				logger.info("Validation Start...");
				String webPageAvailableElements = null;
				String[] selectInputdata = inputdata.split("##");
				int inputDataSize = selectInputdata.length;
				System.out.println("Input Data value Size >>: " +inputDataSize);
				System.out.println("Input Data Text value >>: " +Arrays.toString(selectInputdata));
				List<WebElement> webPageElements = driver.findElements(By.xpath(xmlPath));
				int webPageElementsSize = webPageElements.size();
				passedScreenShotPics();
				System.out.println("Total Available list Size in Web Page: " +webPageElementsSize);
				logger.info("Total Available list Size in Web Page: " +webPageElementsSize);

				for(int i=0; i<webPageElementsSize; i++){   
					for(int j=0; j<inputDataSize; j++){
						webPageAvailableElements = webPageElements.get(i).getText();
						System.out.println("Web Page Available Text -->> : " +webPageAvailableElements);
						logger.info("Web Page Available Text -->> : " +webPageAvailableElements);

						customWait(1);
						if((webPageAvailableElements).equalsIgnoreCase(selectInputdata[i])){
							System.out.println("Expected-->> "+selectInputdata[i]);
							log.info("Expected-->> "+selectInputdata[i]);
							logger.info("Expected-->> "+selectInputdata[i]);
							System.out.println("(" +webPageAvailableElements+ ") is displaying in the web Page:>> PASSED");
							log.info(webPageAvailableElements+ " is displaying in the web Page:>> PASSED");
							logger.pass(webPageAvailableElements+ " is displaying in the web Page:>> PASSED");
							log.info("Actual-->> "+webPageAvailableElements);
							logger.info("Actual-->> "+webPageAvailableElements);
							System.out.println("Actual-->> "+webPageAvailableElements);
							Thread.sleep(500);
							passedScreenShotPics();
							Assert.assertEquals(webPageAvailableElements, selectInputdata[i], "Doesn't match the actual and expected data");
							break;
						}
						else{
							failureScreenShotPics();
							System.out.println("Expected-->> "+selectInputdata[i]);
							log.info("Expected-->> "+selectInputdata[i]);
							logger.info("Expected-->> "+selectInputdata[i]);
							System.out.println("(" +webPageAvailableElements+ ") is not displaying in the web Page:>> FAILED");
							logger.fail("(" +webPageAvailableElements+ ") is not displaying in the web Page:>> FAILED");
							log.info(webPageAvailableElements+ ") is not displaying in the web Page:>> FAILED");
							log.info("Actual-->> "+webPageAvailableElements);
							logger.info("Actual-->> "+webPageAvailableElements);
							System.out.println("Actual-->> "+webPageAvailableElements);
							Assert.fail("Doesn't match the actual and expected data");
						}
					}
				}
				System.out.println("Validation is complete");
				System.out.println("-------------------------------------------------------------------------------");
				log.info("Validation is complete"); 
				logger.info("Validation is complete");
				log.info("-------------------------------------------------------------------------------");

			}
			catch (Exception e){
				failureScreenShotPics();
				logger.fail("Error --->>" +e.getMessage());
				System.out.println("Error --->>" +e.getMessage());
				log.info("Failed");
			}
		}

	}


	public static void customWait(int timeout) throws InterruptedException{
		try {
			Thread.sleep(timeout * 1000);
			logger.info("wait till "+timeout+" second");
		} catch (InterruptedException i) {

		}
	}

	public static void pageDown(int counte) throws InterruptedException, IOException{
		Actions action  =new Actions(driver);
		System.out.println("Page Down Started");
		log.info("Page Down Started");
		logger.info("Page Down Started");
		customWait(2);
		for (int i =0; i<counte ; i++){
			action.sendKeys(Keys.PAGE_DOWN).perform();
			passedScreenShotPics();
			customWait(2);
		}
		System.out.println("Page Down ended");
		log.info("Page Down ended");
		logger.info("Page Down ended");
	}


	public static void mouseHover(String xmlPath) throws InterruptedException{
		util.customWait(2);
		WebElement webLocators = driver.findElement(By.xpath(xmlPath));
		try {
			Actions actions = new Actions(driver);
			log.info("Before mousehover on the element !!!");
			logger.info("Before mousehover on the element !!!");
			actions.moveToElement(webLocators).perform();
			passedScreenShotPics();
			log.info("After mousehover on the element !!!");
			logger.info("After mousehover on the element !!!");
		} catch (Exception e) {
			logger.fail("Not able to move the mouse !!! "+e.getMessage());
			System.out.println("Not able to move the mouse !!! "+e.getMessage());
		}
		customWait(2);
	}




	//=============================================================================================

	public static String createfolder() throws IOException{

		try {
			SCREENSHOT = readPropertiesFileData("SCREENSHOT");
			String destFile="Screenshots/";
			DateFormat dateFormat = new SimpleDateFormat("yyyy.MM.dd HH-mm-sssss");
			String destFolder = dateFormat.format(new Date());

			FOLDER = new File(destFile+ "Screenshot_" +destFolder);
			FOLDER.mkdir();
			System.out.println("Location : " +FOLDER);
			FOLDERPATH = FOLDER  +"/";

		} catch (Exception e) {
			System.err.println("Unable to create folder : "+e.getMessage());
			e.printStackTrace();
		}
		return FOLDERPATH;
	}


	public static void passedScreenShotPics() throws IOException {

		SCREENSHOT_PASS = readPropertiesFileData("SCREENSHOT_PASS");

		try {
			if(SCREENSHOT_PASS.equalsIgnoreCase("Yes")){
				String destFile=""; 
				TakesScreenshot screenshotDriver = (TakesScreenshot)driver;
				File screenshot = screenshotDriver.getScreenshotAs(OutputType.FILE);
				DateFormat dateFormat = new SimpleDateFormat("yyyy.MM.dd HH-mm-ss");

				destFile = FOLDERPATH+"/Success";
				String destDir = dateFormat.format(new Date()) + ".png";
				FileUtils.copyFile(screenshot, new File(destFile+"/"+destDir));
			}
//			else{
//				System.out.println("Success screenshot not required, if needed please enable the flag in property file !!!");
//			}
		}

		catch (Exception e) {
			Assert.fail("Exception while capturing screenshot" +e.getMessage());
		}

	}

	public static void failureScreenShotPics() throws IOException{

		SCREENSHOT_FAIL = readPropertiesFileData("SCREENSHOT_FAIL");

		try {
			if(SCREENSHOT_FAIL.equalsIgnoreCase("Yes")){

				String destFile=null;
				TakesScreenshot screenshotDriver = (TakesScreenshot)driver;
				File screenshot=screenshotDriver.getScreenshotAs(OutputType.FILE);
				DateFormat dateFormat = new SimpleDateFormat("yyyy.MM.dd HH-mm-ss");

				destFile = FOLDERPATH+"/Failure";
				String destDir=dateFormat.format(new Date()) + ".png";
				FileUtils.copyFile(screenshot, new File(destFile+"/"+destDir));
			}
//			else{
//				System.out.println("Failed screenshot not required, if needed please enable the flag in property file !!!");
//			}
		} 

		catch (Exception e) {
			Assert.fail("Exception while capturing screen shot" +e.getMessage());
		}

	}



}
