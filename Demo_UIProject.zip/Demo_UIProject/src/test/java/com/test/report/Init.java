
package com.test.report;

import java.io.File;
import java.io.FileInputStream;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.test.demo.page.OpenCartPage;
import com.test.ui.helper.CommanUtill;

/**
 * @author anil
 *
 * Feb 4, 2023
 */


public class Init {
	
	public static Properties properties = new Properties();
	public static String FEATURE;
	public static FileInputStream fileInput = null;
	public static File file = null;
	public static String PROPERTIES_FILE_PATH = "src/main/java/configuration/configuration_setting.properties";
	public static String LOG_STATUS;
	
	public static File FOLDER;
	public static String FOLDERPATH = "";
	public static String FAILFOLDERPATH = "";
	public static String PASSFOLDERPATH = "";
	public static String SCREENSHOT = "";
	public static String SCREENSHOT_PASS = "";
	public static String SCREENSHOT_FAIL = "";
	
	public static WebDriver driver;
	public static String URL = "";
	public static String BROWSERNAME = "";
	
	public static Logger log = Logger.getLogger("");
	public static String LOG_FILE_PATH;
	public static File REPORTS_FOLDER;
	public static String REPORT_STATUS;
	public static String REPORTS_PATH = "";
	
	public static ExtentHtmlReporter htmlReporter;
	public static ExtentReports extent = new ExtentReports();
	public static ExtentTest logger;
	
	public static CommanUtill util = new CommanUtill();
	public static OpenCartPage cartPage = new OpenCartPage();
	
	

}
