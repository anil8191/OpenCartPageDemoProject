
package com.test.browser.setup;

import io.github.bonigarcia.wdm.WebDriverManager;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import lombok.extern.slf4j.Slf4j;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.safari.SafariDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;
import com.test.report.Init;
import com.test.ui.helper.CommanUtill;


/**
 * @author anil
 *
 * Feb 4, 2023
 */


@Slf4j
@SuppressWarnings("static-access")
public class GeneralBrowserSetting extends Init {
	

	public static CommanUtill util = new CommanUtill();
	static Logger log = Logger.getLogger(GeneralBrowserSetting.class);

	static{

		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy-hh-mm-ss");
		System.setProperty("current.date.time", dateFormat.format(new Date()));
	}

	@BeforeClass
	public static void launchBrowser() throws IOException {
		LOG_STATUS = readPropertiesFileData("LOG_FILE_STATUS");
		if(LOG_STATUS.equalsIgnoreCase("Yes")){
			PropertyConfigurator.configure(readPropertiesFileData("LOG_FILE_PATH"));
		}
		else {
			System.out.println("log file not required...");
			log.info("file path not found....");
		}

		try {
			InputStream input = new FileInputStream(PROPERTIES_FILE_PATH);
			properties.load(input);
			BROWSERNAME = readPropertiesFileData("BROWSERNAME");
			log.info("got the browser name....");
		} catch (Exception e) {
			System.err.println("Error while reading the data from property file!!!" +e.getMessage());
		}
		if(BROWSERNAME.equalsIgnoreCase("Chrome") || BROWSERNAME.equalsIgnoreCase("CHROME")){
			try {
				WebDriverManager.chromedriver().setup();
				log.info("launch chrome browser....");
			} catch (Exception E) {
				System.err.println("Error while loading the data from property file for chrome browser !!!" +E.getMessage());
			} 
			try {
				DesiredCapabilities handlSSLErr = DesiredCapabilities.chrome ();       
				handlSSLErr.setCapability (CapabilityType.ACCEPT_SSL_CERTS, true);
				driver = new ChromeDriver (handlSSLErr);
			} catch (Exception e) {
				System.err.println("Error while reading the data from property file for chrome browser !!!" +e.getMessage());
			}

			URL = readPropertiesFileData("URL");
			log.info("got the url....");

			driver.manage().window().maximize();
			log.info("maximize the windows....");
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			driver.get(URL);
			log.info("entered the url....");
		}
		else if(BROWSERNAME.equalsIgnoreCase("InternetExplorer") || BROWSERNAME.equalsIgnoreCase("IE")){

			try {
				WebDriverManager.iedriver().setup();
				log.info("launch internet explorer browser....");

			} catch (Exception E) {
				System.err.println("Error while loading the data from property file for chrome browser !!!" +E.getMessage());
			}

			//it is used to define IE capability 
			try {
				DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();

				capabilities.setCapability(CapabilityType.BROWSER_NAME, "IE");
				capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS,true);

				driver = new InternetExplorerDriver(capabilities);
			} catch (Exception e) {
				System.err.println("Error while reading the data from property file for IE browser !!!" +e.getMessage());
			}

			URL = readPropertiesFileData("URL");
			log.info("got the url....");

			driver.manage().window().maximize();
			log.info("maximize the windows....");
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			driver.get(URL);
			log.info("entered the url....");
		}


		else if(BROWSERNAME.equalsIgnoreCase("Safari") || BROWSERNAME.equalsIgnoreCase("SAFARI")){

			try {
				driver = new SafariDriver();  
				log.info("launch safari browser....");
				URL = readPropertiesFileData("URL");
				log.info("got the url....");

				driver.manage().window().maximize();
				log.info("maximize the windows....");
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				driver.get(URL);
				log.info("entered the url....");
			} catch (Exception e) {
				System.err.println("Error while launching the safari browser !!!" +e.getMessage());
			}
		}
	}




	@SuppressWarnings("unused")
	protected static String readPropertiesFileData(String propertyName) throws IOException {

		try {
			file = new File(PROPERTIES_FILE_PATH);
			fileInput = null;
			fileInput = new FileInputStream(file);
		} catch (Exception e) {
			System.out.println("File not found on specified location: "+file);
			System.err.println("Error!!! "+e.getMessage());
		}
		try {
			properties.load(fileInput);
		} catch (Exception e) {
			System.out.println("Properties file not loaded !!!" +e.getMessage());
		}

		FEATURE = properties.getProperty(propertyName);
		return FEATURE;

	}


	@BeforeSuite		
	public static void setup() throws IOException{
		InputStream input = new FileInputStream(PROPERTIES_FILE_PATH);
		properties.load(input);
		SCREENSHOT = readPropertiesFileData("SCREENSHOT");

		try {
			if(SCREENSHOT.equalsIgnoreCase("Yes")){
				createfolder();  //Creating a new folder.
			}
			else{
				System.out.println("screenshot not required, if needed please enable the flag in property file !!!");
			}
		} catch (Exception e) {
			System.err.println("Screenshot is not enable in the config file !!!"
					+ "\nPlease enable the Screenshot flag !!!" +e.getMessage());
		}


		try {
			InputStream in = new FileInputStream(PROPERTIES_FILE_PATH);
			properties.load(in);
			REPORT_STATUS = readPropertiesFileData("REPORT");
			if(REPORT_STATUS.equalsIgnoreCase("Yes")){
				createReportFolder();
				String destFile=null;
				DateFormat dateFormat = new SimpleDateFormat("yyyy.MM.dd HH-mm-ss");
				destFile = REPORTS_PATH;
				String destDir = dateFormat.format(new Date()) + ".html";

				htmlReporter = new ExtentHtmlReporter(destFile + "\\" +"New_Report_"+destDir);
				extent = new ExtentReports();

				extent.attachReporter(htmlReporter);
				extent.setSystemInfo("Host Name", "Demo Project Report");
				extent.setSystemInfo("Environment", "Production");
				extent.setSystemInfo("User Name", "AK");
				htmlReporter.config().setDocumentTitle("Demo project automation extent report"); 
				// Name of the report
				htmlReporter.config().setReportName("Demo project extent Report"); 
				// Dark Theme
				htmlReporter.config().setTheme(Theme.STANDARD);
			}
		} catch (Exception e) {

		}

	}



	public static String createfolder() throws IOException{

		try {
			SCREENSHOT = readPropertiesFileData("SCREENSHOT");
			String destFile="Screenshots/";
			DateFormat dateFormat = new SimpleDateFormat("yyyy.MM.dd HH-mm-sssss");
			String destFolder = dateFormat.format(new Date());

			FOLDER = new File(destFile+ "Screenshot_" +destFolder);
			FOLDER.mkdir();
			System.out.println("Location : " +FOLDER);
			FOLDERPATH = FOLDER  +"/";

		} catch (Exception e) {
			System.err.println("Unable to create folder : "+e.getMessage());
			log.error("Unable to create folder : "+e.getMessage());
		}
		return FOLDERPATH;
	}

	public static String createReportFolder() throws IOException{

		try {
			REPORT_STATUS = readPropertiesFileData("SCREENSHOT");
			String destFile="Reports/";
			DateFormat dateFormat = new SimpleDateFormat("yyyy.MM.dd HH-mm-sssss");
			String destFolder = dateFormat.format(new Date());

			REPORTS_FOLDER = new File(destFile+ "HTML_Reports_" +destFolder);
			REPORTS_FOLDER.mkdir();
			System.out.println("Location : " +REPORTS_FOLDER);
			REPORTS_PATH = REPORTS_FOLDER  +"/";

		} catch (Exception e) {
			System.err.println("Unable to create folder : "+e.getMessage());
			log.error("Unable to create folder : "+e.getMessage());
		}
		return REPORTS_PATH;
	}

	@AfterMethod
	public void reportclosewindows() throws IOException, InterruptedException{
		extent.flush();

	}

	@AfterClass
	public static void closeBroser() throws InterruptedException, IOException {
		util.customWait(5);
		util.closeallwindow();
	}

}




