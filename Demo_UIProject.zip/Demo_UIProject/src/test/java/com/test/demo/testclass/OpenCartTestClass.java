
package com.test.demo.testclass;

import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.test.browser.setup.GeneralBrowserSetting;

/**
 * @author anil
 *
 * Feb 4, 2023
 */

@SuppressWarnings("static-access")
public class OpenCartTestClass extends GeneralBrowserSetting {

	public static String actualRegisterAccount;
	public static String expectedRegisterAccount = "Register Account";
	public static String firstName = "Sam";
	public static String lastName = "Joy";
	public static String emailId = "samjoy@gmail.com";
	public static String password = "Sam@123456Joy";
	public static String expectedRegisterPageLinksData = "Login##Register##Forgotten Password##My Account##Address Book##Wish List##"
										+ "Order History##Downloads##Subscriptions##Reward Points##Returns##Transactions##Newsletter";
	public static String expectedCategoryTestData = "Desktops##Laptops & Notebooks##Components##Tablets##Software##Phones & PDAs##"
										+ "Cameras##MP3 Players";
	
	@Test(priority = 1)
	public static void validateDashboard() throws IOException, InterruptedException{
		logger = extent.createTest("validateDashboard", "To validate the Dashboard menu category and sub category");
		
		cartPage.validateCategoryList(expectedCategoryTestData);
		
		cartPage.validateSubCategory("Category List");
	}
	

	@Test(priority = 2)
	public static void registerNewUserClick() throws IOException, InterruptedException{
		logger = extent.createTest("registerNewUserClick", "To register new user registerNewUserClick");

		cartPage.navigateToDashboard("Dashboad Link");
		cartPage.clickOnMyAccount("My Account link");
		cartPage.clickOnRegister("Register Link");
		actualRegisterAccount = cartPage.validateRegisterDashBoardPage();
		System.out.println("Actual Register Account test :: "+actualRegisterAccount);
		Assert.assertEquals(actualRegisterAccount, expectedRegisterAccount, "Doesn't match the expected data !!!");

		cartPage.enterFirstName(firstName, "First Name");
		cartPage.enterLastName(lastName, "Last Name");
		cartPage.enterEmail(emailId, "Email Id");
		cartPage.enterPassword(password, "Password");
		cartPage.clickSubscribeRadioButton("Subscribe button");
		cartPage.clickTnCPolicy("TnC Policy");
		util.customWait(5);
		cartPage.clickcontinueButton("Continue Button");

	}


	@Test(priority = 3)
	public static void validateRegisterPageLinks() throws IOException, InterruptedException{
		logger = extent.createTest("validateRegisterPageLinks", "To validate the register page links");

		cartPage.navigateToDashboard("Dashboad Link");
		cartPage.clickOnMyAccount("My Account link");
		cartPage.validateRegisterPageItems(expectedRegisterPageLinksData);

	}


	@Test(priority = 4)
	public static void addToCartProduct() throws IOException, InterruptedException{
		logger = extent.createTest("addToCartProduct", "Add to cart the product ");

		cartPage.navigateToDashboard("Dashboad Link");
		util.pageDown(1);
		util.customWait(2);
		cartPage.selectProduct("macBook");
		cartPage.addToCartProduct("Add To cart Button");
	}

}
