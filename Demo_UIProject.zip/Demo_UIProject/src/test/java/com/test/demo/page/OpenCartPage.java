
package com.test.demo.page;

import java.io.IOException;

import org.apache.log4j.Logger;

import com.test.browser.setup.GeneralBrowserSetting;

/**
 * @author anil
 *
 * Feb 4, 2023
 */

@SuppressWarnings("static-access")
public class OpenCartPage extends GeneralBrowserSetting {

	static Logger log = Logger.getLogger(GeneralBrowserSetting.class);

	public static String categoryLocator = "//ul[@class='nav navbar-nav']/li/a"; 
	public static String desktopSubcatLocator = "//li[@class='nav-item dropdown']/a";
	public static String laptopsNoteSubcatLocator = "//li[@class='nav-item dropdown']/a[.='Laptops & Notebooks']";
	public static String componentsSubcatLocator = "//li[@class='nav-item dropdown']/a[.='Components']";
	public static String MP3PlayerSubcatLocator = "//li[@class='nav-item dropdown']/a[.='MP3 Players']";

	public static String macBookLocator = "//div[@class='product-thumb']//a[.='MacBook']";
	public static String addToCartButton = "//button[@id='button-cart']";
	public static String subCategory = "//div[@class='dropdown-inner']//li//a";
	public static String desktopLocator = "";
	
	//Register user
	public static String registerXPath = "//aside[@id='column-right']//a[.='Register']";
	public static String myAccountXPath= "//ul[@class='list-unstyled']//a[.='My Account']";
	public static String registerDashboard = "//div[@id='content']/h1";
	
	public static String firstNameXPath = "//input[@id='input-firstname']";
	public static String lastNameXPath = "//input[@id='input-lastname']";
	public static String emailXPath = "//input[@id='input-email']";
	public static String passwordXPath = "//input[@id='input-password']";
	public static String subscribeXPath = "//input[@id='input-newsletter-yes']";
	public static String tncPolicyXPath = "//input[@name='agree']";
	public static String continueButtonXPath = "//button[@class='btn btn-primary']";
	
	public static String registerPageLinks = "//aside[@id='column-right']//a";
	
	public static String dashboadLink = "//img[@title='Your Store']";

	public static void validateCategoryList(String inputData) throws IOException, InterruptedException{

		util.alltextValidation(categoryLocator, inputData);
		
	}
	
	public static void validateDesktopSubCategoryList(String inputData) throws InterruptedException, IOException{
		
		util.mouseHover(desktopSubcatLocator);
		validateCategoryList(inputData); 
	}
	
	public static void clickOnMyAccount(String fieldName) throws IOException, InterruptedException{
		util.pageDown(3);
		util.click(myAccountXPath, fieldName);
	}
	
	public static void clickOnRegister(String fieldName) throws IOException, InterruptedException{
		util.click(registerXPath, fieldName);
	}
	
	public static String validateRegisterDashBoardPage() throws IOException, InterruptedException{
		return util.validateText(registerDashboard, "Register dashboard page !!!");
	}
	
	public static void enterFirstName(String inputData, String fieldName) throws IOException, InterruptedException{
		util.enterText(firstNameXPath, inputData, fieldName);
	}
	
	public static void enterLastName(String inputData, String fieldName) throws IOException, InterruptedException{
		util.enterText(lastNameXPath, inputData, fieldName);
	}
	
	public static void enterEmail(String inputData, String fieldName) throws IOException, InterruptedException{
		util.enterText(emailXPath, inputData, fieldName);
	}
	
	public static void enterPassword(String inputData, String fieldName) throws IOException, InterruptedException{
		util.enterText(passwordXPath, inputData, fieldName);
	}
	
	public static void clickSubscribeRadioButton(String fieldName) throws IOException, InterruptedException{
		util.pageDown(2);
		util.click(subscribeXPath, fieldName);
	}
	
	public static void clickTnCPolicy(String fieldName) throws IOException, InterruptedException{
		util.click(tncPolicyXPath, fieldName);
	}
	
	public static void clickcontinueButton(String fieldName) throws IOException, InterruptedException{
		util.click(continueButtonXPath, fieldName);
	}
	
	public static void validateRegisterPageItems(String inputData) throws IOException, InterruptedException{
		util.alltextValidation(registerPageLinks, inputData);
	}
	
	
	public static void selectProduct(String fieldName) throws IOException, InterruptedException{
		util.click(macBookLocator, fieldName);
	}
	
	public static void addToCartProduct(String fieldName) throws IOException, InterruptedException{
		util.click(addToCartButton, fieldName);
	}
	
	public static void validateSubCategory(String fieldName) throws InterruptedException, IOException{
		util.validateSubCategory(desktopSubcatLocator, fieldName);
	}
	
	
	public static void navigateToDashboard(String fieldName) throws IOException, InterruptedException{
		util.click(dashboadLink, fieldName);
	}
	
	
}
